<div id="wrapper4">
    <div id="footer" class="container">
        <div>
            <header class="title">
                <h2>Get in touch</h2>
                <span class="byline">Connect with Me!</span> </header>
            <ul class="contact">
                <li><a href="https://www.facebook.com/kimmoonseop" class="icon icon-facebook"><span></span></a></li>
                <li><a href="https://www.linkedin.com/in/moon-seop-kim-a2a95564" class="icon icon-linkedin"><span>LinkedIn</span></a></li>
            </ul>
        </div>
    </div>
</div>
<div id="copyright" class="container">
    <p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>

<?php
/**
 * Created by PhpStorm.
 * User: moons
 * Date: 3/11/2016
 * Time: 8:47 AM
 */

