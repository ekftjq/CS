<div id="wrapper2">
    <div id="welcome" class="container">
        <div class="title">
            <h2>Welcome to my Portfolio!</h2>
        </div>
        <p>Hello! My name is <strong>Moon Seop Kim</strong>. I am a Computer Science student in University of Illinois at Urbana-Champaign.
            I am a driven computer science student who wants to do things that can help make the world a better place.
            I enjoy programming and love getting immersed with code.</p>
    </div>
</div>